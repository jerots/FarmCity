/**
* starting point of the app 
*/

import menu.*;
public class FarmCityApp{
	
		
		
	public static void main(String[] args){
		FarmCityMenu menu = new FarmCityMenu();
		menu.display();
		
		
		
	}
}