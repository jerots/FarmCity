package manager;

import java.io.*;
import java.util.*;
import entity.*;


/**
* manages the Create, Retrieve, Update, Delete of Users 
*/

public class UserManager {
	/**
	* @param USERFILE location of the user database file
	* @param userList the temp memory of users list
	*/
	private final File USERFILE = new File("data/userFile.csv");
	private ArrayList<User> userList;
	

		
	
	
	public UserManager(){
		userList = new ArrayList<>();
		load();
	}
	
	/**
	* Save into file
	*/
	public void save(){
		
		try{
			PrintStream writer = new PrintStream(new FileOutputStream(USERFILE, false));

			writer.println("Username,Full Name,Password,Gold,Exp");
			for (int i = 0; i < userList.size(); i++){
				User current = userList.get(i);
				writer.println(current.getUsername() + "," + current.getFullName() + "," + current.getPassword() + "," + current.getGold() + "," + current.getExp());
				
			}
		} catch (Exception e){
			e.printStackTrace();
		}
	}
	
	/**
	* Load into file
	*/
	public void load(){
		
		Scanner sc = null;
		try {
			sc = new Scanner(USERFILE);
		} catch (Exception e){
			e.printStackTrace();
		}
		sc.nextLine(); //skip headers
		userList.clear(); //clear arraylist before loading
		
		while (sc.hasNextLine()){
		
			Scanner scanLine = new Scanner(sc.nextLine());
			
			scanLine.useDelimiter(",");
			String retrUsername = scanLine.next();
			String retrName = scanLine.next();
			String retrPassword = scanLine.next();
			
			int gold = Integer.parseInt(scanLine.next());
			int exp = Integer.parseInt(scanLine.next());
			
			userList.add(new User(retrUsername, retrName, retrPassword, gold, exp));
		}
	}
	
	/**
	* Create a new user
	* @return create a new user
	* @param username the username of the user
	* @param fullName the full name of the user
	* @param password the password of the user
	*/
	public User createUser( String username, String fullName, String password){
		
		for (int i = 0; i < userList.size(); i++){
			User current = userList.get(i);
			if (current.getUsername().equals(username)){
				return null; //if username exists, createUser() fails
			}
		}
		
		User newUser = new User(username, fullName, password);
		userList.add(newUser);
		save();
	
		return newUser;
	}
	
	/**
	* Retrieve a user based on username
	* @return retrieve user based on username only
	* @param username the username of the user to be retrieved
	*/
	public User retrieveUser(String username){
	
		for (int i = 0; i < userList.size(); i++){
			User current = userList.get(i);
			if (current.getUsername().equals(username)){
				return current;
			}
		}
		return null;
	}
	
	/**
	*Retrieve a user based on username and password (includes validation)
	* @return retrieve user based on username and password (password must be correct, else null)
	* @param username the username of the user
	* @param password the password of the user
	*/
	public User retrieveUser(String username, String password){ //for login
		
		for (int i = 0; i < userList.size(); i++){
			User current = userList.get(i);
			if (current.getUsername().equals(username) && current.getPassword().equals(password)){
				return current;
			}
		}
		return null;
		
		
	}

	/**
	* Update a user
	* @param username the username of the updated user
	* @param newUser the user object with the updated details
	*/
	public void updateUser(String username, User newUser){
		for (int i = 0; i < userList.size(); i++){
			User current = userList.get(i);
			if (current.getUsername().equals(username)){
				userList.set(i, newUser);
			}
		}
		save();
	}
	
	


}